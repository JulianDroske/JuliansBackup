require('./audio');
require('./JuRt');
const fs = require('fs');

var freqMax = 1000;

function min(a, b){
	if(a<b) return a;
	return b;
}

var wav = new WAV();
var data = wav.parseFile('./Stay.wav');

var starts = process.argv[2];

//fs.writeFileSync('Stay.wav.dump', JSON.stringify(data));
// var data = JSON.parse(fs.readFileSync('Stay.wav.dump'));

var head = data[0];
var dat = data[1][0];	// Only left channel
console.log('Header: ', head)

// return: 3.918

// fsampleRate = 0.1s = 10Hz
var fsampleRate = 20;

const pCount = (head.sampleRate/fsampleRate)|0;

if(pCount/2 < freqMax){
	console.log('Warning: Invalid Max Frequence '+freqMax+', available maxFreq='+(pCount/2|0));
}

// From part of FSV.js
var f = [];
for(var i=0|(parseFloat(starts)*head.sampleRate), n=i+pCount; i<n; ++i){
	f.push(dat[i]);
}

/* var vectors = [];	// freq
for(var i=0, v=0.5, vN=100;i<vN;++i,v+=0.5){
	var c_n = new C();
	// sum
	for(var k=0,j=0; j<pCount; k++,j++){
		c_n = c_n.plus(new V(f[k], -2 * (0|v)*Math.pow(-1,i) * j).toC());
	}
	vectors.push(new V(c_n, 2*(0|v)*Math.pow(-1,i)));
	// console.log(c_n.a + ';' + c_n.b);
}*/

////////
var vectors = [];	// freq
for(var i=100, vN=min((pCount/2)|0, freqMax);i<vN;++i){
	// var c_n = new C();
	var cA=0;
	// sum
	/* for(var j=0, k=0; j<=1; j+=1/pCount, ++k){
		c_n = c_n.plus(new V(f[k], -2 * i * j).toC());
		// if(i==501) console.log(f[k], new V(f[k], -2*i*j), new V(f[k], -2*i*j).toC().getPoint())
	}*/
	for(var j=0; j<pCount; ++j){
		var s = -2*i*j*Math.PI/pCount;
		// c_n.plusSelf(C.fromVstruct(f[j], -2 * i * j / pCount));
		cA += f[j] * Math.cos(s);
		// cB += f[j] * Math.sin(s);
	}
	// vectors.push(new V(c_n, 2*(0|v)*Math.pow(-1,i)));
	vectors.push(cA);
	// console.log(c_n.a + ';' + c_n.b);
}

// return 

// return 6.724
// return: 9.766
// return: 48.693
// j=for 0,4410
// i=for 100,1000
// i*j=for 0,3969000

/*for(var i=0;i<vectors.length;++i){
	console.log('Freq ', i, ': ', vectors[i].getPoint());
}*/

/* const height = 65536;
const per = 32;
var c = new Canvas(data[0].length/1000, height/per, null, null, true);
var z=0;
for(var i=z, n=data[0].length/1000 + z;i<n;++i){
	c.lineTo((i-z) ,data[0][i*1000]/per + height/per/2);
}
// TODO: negative int unsupported 
c.stroke();
c.outputBMP();
*/

// fourier!
var width = 800;
var height = 600;
var c = new Canvas(width, height);
var cx=width/2;
var cy=height/2;

for(var i=0;i<vectors.length;++i){
	var p = vectors[i]/2000;
	if(i==0){
		// c.moveTo(p[0]+cx, p[1]+cy);
		c.moveTo(i, p+cy);
	}else{
		// c.lineTo(p[0]+cx, p[1]+cy);
		c.lineTo(i, p+cy);
	}
}





// const height = 65536;
// var c = new Canvas(data[0].length/1000, height/per, null, null, true);
/* for(var i=0;i<width;++i){
	if(i==0){
		c.moveTo(i ,f[i]/100 + height/2);
	}else{
		c.lineTo(i ,f[i]/100 + height/2);
	}
}*/






c.stroke();
c.outputMPEG(true);
