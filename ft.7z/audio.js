const fs = require('fs');
require('./jurf.js');

function WAV(){
	
	var head;
	var cfg = [4,4,4,4,4,2,2,4,4,2,2,4,4];
	var ncfg = [0,1,0,0,1,1,1,1,1,1,1,0,1];
	var data;
	
	this.parseFile = function(path){
		head = deployObj(fread(path, cfg, ncfg), [
			'chunkId',
			'chuckSize',
			'format',
			'subchunk1Id',
			'subchunk1Size',
			'audioFormat',
			'numChannels',
			'sampleRate',
			'byteRate',
			'blockAlign',
			'bitsPerSample',
			'subchunk2Id',
			'subchunk2Size'
		]);
		
		var dat = fread(path, [head.subchunk2Size], null, 44+8)[0];
		
		// var fp;	// for faster speed
		// if(!(fp=fs.openSync(path, 'r'))) return;
		const len = 0|(head.subchunk2Size/(head.bitsPerSample/8))/head.numChannels;
		data = new Array();
		for(var i=0;i<head.numChannels;++i){
			data[i] = new Array();
		}
		for(var i=0, perbyte=(head.bitsPerSample/8)|0, nowpos=0;i<len;++i,nowpos+=perbyte){
			for(var j=0;j<head.numChannels;++j){
				data[j][i] = byte2num(dat.substr(nowpos, perbyte), true);	// fpread(fp, 0, perbyte, nowpos, true);
			}
		}
		// fs.closeSync(fp);
		return [head, data];
	}
	
	
	
}

GLOBAL.WAV = WAV;
