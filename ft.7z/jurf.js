const fs = require('fs')

function deployObj(data, names){
	if(names.length != data.length) return null;
	var n = names.length;
	
	var tarobj = {};
	
	for(var i=0;i<n;++i){
		tarobj[names[i]] = data[i];
	}
	
	return tarobj;
}

function byte2num(bytes, signed){
	bytes = bytes.toString('binary');
	var num=0;
	const len = bytes.length;
	for(var j=len-1;j>=0;--j){
		num *= 256;
		num += bytes.charCodeAt(j);
		/* num <<= 8;
		num |= bytes.charCodeAt(j)&0xff;*/
	}
	if(signed && (bytes.charCodeAt(len-1) & 128)){
		// console.log(new Buffer(bytes))
		num |= ~(Math.pow(2,len*8)-1);
		// console.log(new Buffer(bytes))
	}
	return num;
}

function fpread(fp, offset, len, pos, isNum){
	// var buf = new Buffer(len);
	var buf = fs.readSync(fp, len, pos, 'binary')[0];
	buf = buf.toString('binary');
	if(!!isNum){
		buf = byte2num(buf);
	}
	return buf;
}

function fread(path, cfg, numcfg, position){
	
	// cfg: bits
	// numcfg: - default number
	
	var fp;
	
	if((!(cfg instanceof Array)) || !(fp=fs.openSync(path, 'r'))) return null;
	position = position || 0;
	numcfg = numcfg || [];
	
	var len = cfg.length;
	
	var data = new Array(len);
	
	for(var i=0, lst=position;i<len;lst+=cfg[i],++i){
		/* var buf = new Buffer(cfg[i]);
		fs.readSync(fp, buf, 0, cfg[i], lst);
		data[i] = buf.toString('binary');
		if(!!numcfg[i]){
			var dat = data[i];
			var num=0;
			for(var j=cfg[i]-1;j>=0;--j){
				num *= 256;
				num += dat.charCodeAt(j);
			}
			data[i] = num;
		}*/
		data[i] = fpread(fp, 0, cfg[i], lst, numcfg[i]);
	}
	
	fs.closeSync(fp);
	
	return data;
}

GLOBAL.deployObj = deployObj;
GLOBAL.fread = fread;
GLOBAL.fpread = fpread;
GLOBAL.byte2num = byte2num;
